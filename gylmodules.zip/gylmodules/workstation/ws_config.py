#  === message type ===
# 通知消息
NOTIFICATION_MESSAGE = 0
# 私聊
PRIVATE_CHAT = 1
# 群聊
GROUP_CHAT = 2


#  === redis config ===
REDIS_HOST = '127.0.0.1'
REDIS_PORT = 6379
REDIS_DB = 2


#  === redis key (new record) ===
NEW_MESSAGE = 'NEW-MESSAGE'
NEW_HISTORICAL_CONTACTS_RECORD = 'NEW-HISTORICAL-CONTACTS-RECORD'


# ===========================================================
# =============         mail            =====================
# ===========================================================

MAIL_DOMAIN = '@nsyy.com'
MAIL_ACCOUNT_PASSWORD = 'nsyy0601'
MAIL_MAILBOX = 'INBOX'

# SSH connection details
MAIL_SSH_HOST = "192.168.124.128"
MAIL_SSH_USERNAME = "root"
MAIL_SSH_PASSWORD = "111111"
MAIL_SMTP_PORT = 587
MAIL_IMAP_PORT = 993

MAIL_OPERATE_UPDATE = 0
MAIL_OPERATE_ADD = 1
MAIL_OPERATE_REMOVE = 2
MAIL_OPERATE_PUBLIC = 3
MAIL_OPERATE_DELETE = 4

NEW_MAIL_KEY = 'NEW-MAIL'
ADD_MAIL_ACCOUNT_KEY = 'ADD-MAIL-ACCOUNT'
REMOVE_MAIL_ACCOUNT_KEY = 'REMOVE-MAIL-ACCOUNT'
DELETE_MAIL_GROUP_KEY = 'DELETE-MAIL-GROUP'
DELETE_MAIL_ACCOUNT_KEY = 'DELETE-MAIL-ACCOUNT'


# ===========================================================
# =============         fail            =====================
# ===========================================================


FILE_UPLOAD_FOLDER = '/uploads'
FILE_DOWNLOAD_FOLDER = '/downloads'
FILE_ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'zip'}


# sftp config
FILE_SFTP_HOST = '192.168.124.128'
FILE_SFTP_PORT = 22
FILE_SFTP_USERNAME = 'root'
FILE_SFTP_PASSWORD = '111111'
FILE_SFTP_REMOTE_FILES_PATH = '/home/yanliang/file-manager'

# SSH connection details
FILE_SSH_HOST = "192.168.124.128"
FILE_SSH_USERNAME = "root"
FILE_SSH_PASSWORD = "111111"

# file scope (全院，部门，项目，个人)
FILE_SCOPE = {1, 2, 3, 4}
FILE_SCOPE_ALL = 1
FILE_SCOPE_DEPT = 2
FILE_SCOPE_PROJECT = 3
FILE_SCOPE_PERSON = 4