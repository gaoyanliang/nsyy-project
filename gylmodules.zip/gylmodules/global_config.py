# 全局配置

# db config
DB_HOST = '192.168.3.12'
DB_PORT = 3306
DB_USERNAME = 'gyl'
DB_PASSWORD = '123456'
DB_DATABASE_GYL = 'nsyy_gyl'
DB_DATABASE_GENERAL = 'nsyy_general'
DB_TABLE_MENU = 'menu'
DB_TABLE_SPORTS_ACTIONS = 'sports_actions'

# DB_HOST = '127.0.0.1'
# DB_PORT = 3306
# DB_USERNAME = 'root'
# DB_PASSWORD = 'gyl.2015'
# DB_DATABASE_GYL = 'nsyy_gyl'

